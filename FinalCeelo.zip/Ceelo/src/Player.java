/*
    Joseph Alarid, Maria Lans, Simon Tran
    10 December 2017
    Player.java
    Player class for Cee Lo game
*/
public class Player {

    //properties of Player
    private String name = "null";
    private int balance = 1000;
    int point = 0;

    //default constructor
    Player(){
        name = null;
        balance = 1000;
        point = 0;
    }

    //constructor with name
    Player(String n){
        name = n;
        balance = 1000;
        point = -1;
    }

    //method updates balance amount
    public void updateBalance(int b){
        balance += b;
    }

    //method returns balance amount
    public int getBalance(){
        return balance;
    }

    //method return name
    public String getName(){
        return name;
    }

    //method update points
    public void updatePoint(int p){
        point = p;
    }

    //reset points for beginning game
    public void resetPoint(){
        point = -1;
    }

    //method return point value
    public int getPoint(){
        return point;
    }
}
