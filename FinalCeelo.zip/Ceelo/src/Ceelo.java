/*
    Joseph Alarid, Maria Lans, Simon Tran
    10 December 2017
    Ceelo.java
    Program to play the game Cee Lo
    Dice.java, Player.java
*/

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.Scanner;
import java.io.File;
import java.net.URI;


public class Ceelo {

    //scanner object
    static Scanner input = new Scanner(System.in);

    //an array for players
    private static final int playerCount = 50; //number of total players allowed in the array list
    private static int nextPlayerCount = 0; //number of all players in the database
    private static Player[] players = new Player[playerCount]; //

    //METHOD MENU
    public static void main(String[] args) {

        //variables for the menu
        int neverAgain = 0; // used to end the welcome prompt
        int menuChoice; //user's choice on menu
        boolean endgame = false; //used to end program

        //loops menu until quit program
        while (endgame == false) {

            //welcome to print once
            while (neverAgain == 0) {
                System.out.println("Welcome to Cee Lo Java");
                neverAgain++;
            }

            //menu choices
            System.out.println("\n(1) Print Rules");
            System.out.println("(2) Start Game");
            System.out.println("(3) Print Leaderboard");
            System.out.println("(4) Play a video Tutorial");
            System.out.println("(5) Quit Game");
            System.out.printf("%nWhat would you like to do? ");
            menuChoice = input.nextInt();

            //execute menu through switch statement
            switch (menuChoice) {
                case 1:
                    rules();
                    break;
                case 2:
                    startGame();
                    break;
                case 3:
                    print();
                    break;
                case 4:
                    video();
                    break;
                default:
                    System.out.println("\nClosing program...");
                    endgame = true;
                    break;
            }
        }
    }

    //METHOD RULES
    public static void rules() // prints the rules of the game to the screen
    {
        //rule prompt
        System.out.println("\nEach player will roll 3 dice. \nA combination of 4-5-6 is an auto-win, 1-2-3 is an auto-lose");
        System.out.println("If a pair is rolled, the 3rd dice value will be that player's set point. \nThe higher set point trumps the lower set point.");
        System.out.println("Rolling 3 of the same number is called a TRIP. \nTRIPS trumps a set point and higher trip values trumps lower trip values.");
        System.out.println("The player will roll until they have a legal combination.\n");
    }

    //METHOD PLAY GAME
    public static void startGame() { // starts a round of ceelo

        //variables for game
        int playerNum = 0;
        int currentPlayer;

        //array for players in game
        Player[] currentlyPlaying = new Player[4];

        //determine number of players
        while (playerNum != 2 && playerNum != 3 && playerNum != 4) {
            System.out.print("How many players will be in this game? (2-4) ");
            playerNum = input.nextInt();
        }

        //adds players to the current game
        for (int n = 1; n <= playerNum; n++) {
            String username;
            currentPlayer = -1;

            System.out.printf("%n%nPlayer %d, please enter your name: ", n);
            username = input.next();

            //checks to see if name is already registered
            for (int p = 0; p < nextPlayerCount; p++) {
                //compares names, ignoring case
                if (players[p].getName().equalsIgnoreCase(username)) {
                    currentPlayer = p;
                }
            }

            //if player is registered, enter them into the game
            if (currentPlayer != -1) {
                currentlyPlaying[n] = players[currentPlayer];
            } else //if they are not registered, make new player
            {
                System.out.printf("Creating new player: %s, your starting balance is 1000.", username);
                players[nextPlayerCount] = new Player(username);
                currentlyPlaying[n] = players[nextPlayerCount];
                nextPlayerCount++;
            }
        }

        //set variables for game
        int bet = 0, pot = 0;

        //ask bet amounts for each player
        for (int n = 1; n <= playerNum; n++) {
            //determine bet amount
            System.out.printf("%n%n%s, place your bet: ", currentlyPlaying[n].getName());
            bet = input.nextInt();

            //updates balance for all players
            if (currentlyPlaying[n].getBalance() - bet >= 0) {
                pot += bet;
                currentlyPlaying[n].updateBalance(-bet);
                System.out.printf("%s went in with %d, they now have %d remaining.", currentlyPlaying[n].getName(), bet, currentlyPlaying[n].getBalance());
            } else //if a player does not have enough they bet the rest of their money
            {
                System.out.printf("%s went all in with %d, their remaining sum is 0.", currentlyPlaying[n].getName(), currentlyPlaying[n].getBalance());
                pot += currentlyPlaying[n].getBalance();
                currentlyPlaying[n].updateBalance(-currentlyPlaying[n].getBalance());
            }
        }
        System.out.printf("%n%nThe pot is %d", pot);

        for (int i = 1; i <= playerNum; i++) {

            System.out.printf("\n\n%s rolls the dice.", currentlyPlaying[i].getName());

            //makes dice objects
            Dice dice1 = new Dice(); // creates object dice 1
            Dice dice2 = new Dice(); // creates object dice 2
            Dice dice3 = new Dice(); // creates object dice 3

            while (currentlyPlaying[i].getPoint() == -1) {

                //rolls dice
                dice1.roll();
                dice2.roll();
                dice3.roll();

                int roll1 = dice1.getRoll(); //sets dice values to ints
                int roll2 = dice2.getRoll();
                int roll3 = dice3.getRoll();
                int rollTotal = roll1 + roll2 + roll3;

                if (roll1 == roll2 && roll2 == roll3) {
                    System.out.printf("\n%s rolled TRIPS! Your TRIP value is %d", currentlyPlaying[i].getName(), roll1);
                    currentlyPlaying[i].updatePoint(roll3 + 6);

                } else if (roll1 == roll2) {
                    System.out.printf("\n%s rolled a %d, %d, and a %d. Your set point is %d.", currentlyPlaying[i].getName(), roll1, roll2, roll3, roll3);
                    currentlyPlaying[i].updatePoint(roll3);

                } else if (roll1 == roll3) {
                    System.out.printf("\n%s rolled a %d, %d, and a %d. Your set point is %d.", currentlyPlaying[i].getName(), roll1, roll3, roll2, roll2);
                    currentlyPlaying[i].updatePoint(roll2);

                } else if (roll2 == roll3) {
                    System.out.printf("\n%s rolled a %d, %d, and a %d. Your set point is %d.", currentlyPlaying[i].getName(), roll2, roll3, roll1, roll1);
                    currentlyPlaying[i].updatePoint(roll1);
                } else if (rollTotal == 15) // if user rolls a 4,5, or 6 the game ends
                {
                    System.out.printf("\nDice are hot. %s rolled a %d, %d, and %d.", currentlyPlaying[i].getName(), roll1, roll2, roll3);
                    currentlyPlaying[i].updatePoint(19);
                } else if (rollTotal == 6) // if user rolls a 1, 2, or 3 the game ends
                {
                    System.out.printf("\nNot today, %s. You rolled a %d, %d, and %d", currentlyPlaying[i].getName(), roll1, roll2, roll3);
                    currentlyPlaying[i].updatePoint(0);

                } else if (roll1 != roll2 && roll1 != roll3 && roll2 != roll3) // if no doubles are rolled the loop resets itself.
                {
                    System.out.printf("\n%s rolled a %d, %d, and a %d. Rerolling...", currentlyPlaying[i].getName(), roll2, roll3, roll1);
                    currentlyPlaying[i].updatePoint(-1);
                }
            }
        }

        //check winner and update balance
        if (playerNum == 4) {
            if (currentlyPlaying[1].getPoint() == currentlyPlaying[2].getPoint() && currentlyPlaying[2].getPoint() == currentlyPlaying[3].getPoint() && currentlyPlaying[3].getPoint() == currentlyPlaying[4].getPoint()) {
                System.out.println("All players have tied! The pot will be shared evenly.");
                currentlyPlaying[1].updateBalance(pot / 4);
                currentlyPlaying[2].updateBalance(pot / 4);
                currentlyPlaying[3].updateBalance(pot / 4);
                currentlyPlaying[4].updateBalance(pot / 4);
                updateScoreboard(currentlyPlaying, playerNum);

            } else if (currentlyPlaying[1].getPoint() == currentlyPlaying[2].getPoint() && currentlyPlaying[2].getPoint() == currentlyPlaying[3].getPoint() && currentlyPlaying[1].getPoint() > currentlyPlaying[4].getPoint()) {
                System.out.printf("%n%n%s, %s,and %s have won the pot!", currentlyPlaying[1].getName(), currentlyPlaying[2].getName(), currentlyPlaying[3].getName());
                currentlyPlaying[1].updateBalance(pot / 3);
                currentlyPlaying[2].updateBalance(pot / 3);
                currentlyPlaying[3].updateBalance(pot / 3);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[1].getPoint() == currentlyPlaying[2].getPoint() && currentlyPlaying[2].getPoint() == currentlyPlaying[4].getPoint() && currentlyPlaying[1].getPoint() > currentlyPlaying[3].getPoint()) {
                System.out.printf("%n%n%s, %s,and %s have won the pot!", currentlyPlaying[1].getName(), currentlyPlaying[2].getName(), currentlyPlaying[4].getName());
                currentlyPlaying[1].updateBalance(pot / 3);
                currentlyPlaying[2].updateBalance(pot / 3);
                currentlyPlaying[4].updateBalance(pot / 3);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[1].getPoint() == currentlyPlaying[3].getPoint() && currentlyPlaying[3].getPoint() == currentlyPlaying[4].getPoint() && currentlyPlaying[1].getPoint() > currentlyPlaying[2].getPoint()) {
                System.out.printf("%n%n%s, %s,and %s have won the pot!", currentlyPlaying[1].getName(), currentlyPlaying[3].getName(), currentlyPlaying[4].getName());
                currentlyPlaying[1].updateBalance(pot / 3);
                currentlyPlaying[3].updateBalance(pot / 3);
                currentlyPlaying[4].updateBalance(pot / 3);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[2].getPoint() == currentlyPlaying[3].getPoint() && currentlyPlaying[3].getPoint() == currentlyPlaying[4].getPoint() && currentlyPlaying[2].getPoint() > currentlyPlaying[1].getPoint()) {
                System.out.printf("%n%n%s, %s,and %s have won the pot!", currentlyPlaying[2].getName(), currentlyPlaying[3].getName(), currentlyPlaying[4].getName());
                currentlyPlaying[2].updateBalance(pot / 3);
                currentlyPlaying[3].updateBalance(pot / 3);
                currentlyPlaying[4].updateBalance(pot / 3);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[1].getPoint() == currentlyPlaying[2].getPoint() && currentlyPlaying[1].getPoint() > currentlyPlaying[3].getPoint() && currentlyPlaying[1].getPoint() > currentlyPlaying[4].getPoint()) {
                System.out.printf("%n%n%s and %s have won the pot!", currentlyPlaying[1].getName(), currentlyPlaying[2].getName());
                currentlyPlaying[1].updateBalance(pot / 2);
                currentlyPlaying[2].updateBalance(pot / 2);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[1].getPoint() == currentlyPlaying[3].getPoint() && currentlyPlaying[1].getPoint() > currentlyPlaying[2].getPoint() && currentlyPlaying[1].getPoint() > currentlyPlaying[4].getPoint()) {
                System.out.printf("%n%n%s and %s have won the pot!", currentlyPlaying[1].getName(), currentlyPlaying[3].getName());
                currentlyPlaying[1].updateBalance(pot / 2);
                currentlyPlaying[3].updateBalance(pot / 2);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[1].getPoint() == currentlyPlaying[4].getPoint() && currentlyPlaying[1].getPoint() > currentlyPlaying[2].getPoint() && currentlyPlaying[1].getPoint() > currentlyPlaying[3].getPoint()) {
                System.out.printf("%n%n%s and %s have won the pot!", currentlyPlaying[1].getName(), currentlyPlaying[4].getName());
                currentlyPlaying[1].updateBalance(pot / 2);
                currentlyPlaying[4].updateBalance(pot / 2);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[2].getPoint() == currentlyPlaying[3].getPoint() && currentlyPlaying[2].getPoint() > currentlyPlaying[1].getPoint() && currentlyPlaying[2].getPoint() > currentlyPlaying[4].getPoint()) {
                System.out.printf("%n%n%s and %s have won the pot!", currentlyPlaying[2].getName(), currentlyPlaying[3].getName());
                currentlyPlaying[2].updateBalance(pot / 2);
                currentlyPlaying[3].updateBalance(pot / 2);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[2].getPoint() == currentlyPlaying[4].getPoint() && currentlyPlaying[2].getPoint() > currentlyPlaying[1].getPoint() && currentlyPlaying[2].getPoint() > currentlyPlaying[3].getPoint()) {
                System.out.printf("%n%n%s and %s have won the pot!", currentlyPlaying[2].getName(), currentlyPlaying[4].getName());
                currentlyPlaying[2].updateBalance(pot / 2);
                currentlyPlaying[4].updateBalance(pot / 2);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[4].getPoint() == currentlyPlaying[3].getPoint() && currentlyPlaying[4].getPoint() > currentlyPlaying[1].getPoint() && currentlyPlaying[4].getPoint() > currentlyPlaying[2].getPoint()) {
                System.out.printf("%n%n%s and %s have won the pot!", currentlyPlaying[4].getName(), currentlyPlaying[3].getName());
                currentlyPlaying[4].updateBalance(pot / 2);
                currentlyPlaying[3].updateBalance(pot / 2);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[1].getPoint() > currentlyPlaying[2].getPoint() && currentlyPlaying[1].getPoint() > currentlyPlaying[3].getPoint() && currentlyPlaying[1].getPoint() > currentlyPlaying[4].getPoint()) {
                System.out.printf("%n%n%s has won the pot!", currentlyPlaying[1].getName());
                currentlyPlaying[1].updateBalance(pot);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[2].getPoint() > currentlyPlaying[1].getPoint() && currentlyPlaying[2].getPoint() > currentlyPlaying[3].getPoint() && currentlyPlaying[2].getPoint() > currentlyPlaying[4].getPoint()) {
                System.out.printf("%n%n%s has won the pot!", currentlyPlaying[2].getName());
                currentlyPlaying[2].updateBalance(pot);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[3].getPoint() > currentlyPlaying[1].getPoint() && currentlyPlaying[3].getPoint() > currentlyPlaying[2].getPoint() && currentlyPlaying[3].getPoint() > currentlyPlaying[4].getPoint()) {
                System.out.printf("%n%n%s has won the pot!", currentlyPlaying[3].getName());
                currentlyPlaying[3].updateBalance(pot);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[4].getPoint() > currentlyPlaying[1].getPoint() && currentlyPlaying[4].getPoint() > currentlyPlaying[2].getPoint() && currentlyPlaying[4].getPoint() > currentlyPlaying[3].getPoint()) {
                System.out.printf("%n%n%s has won the pot!", currentlyPlaying[4].getName());
                currentlyPlaying[4].updateBalance(pot);
                updateScoreboard(currentlyPlaying, playerNum);
            }

            for (int i = 0; i < nextPlayerCount; i++) {
                if (players[i].getName().equalsIgnoreCase(currentlyPlaying[1].getName())) {
                    players[i] = currentlyPlaying[1];
                } else if (players[i].getName().equalsIgnoreCase(currentlyPlaying[2].getName())) {
                    players[i] = currentlyPlaying[2];
                } else if (players[i].getName().equalsIgnoreCase(currentlyPlaying[3].getName())) {
                    players[i] = currentlyPlaying[3];
                } else if (players[i].getName().equalsIgnoreCase(currentlyPlaying[4].getName())) {
                    players[i] = currentlyPlaying[4];
                }
            }
        }

        if (playerNum == 3) {
            if (currentlyPlaying[1].getPoint() == currentlyPlaying[2].getPoint() && currentlyPlaying[2].getPoint() == currentlyPlaying[3].getPoint()) {
                System.out.printf("%n%nAll players have tied! The pot will be shared evenly!");
                currentlyPlaying[1].updateBalance(pot / 3);
                currentlyPlaying[2].updateBalance(pot / 3);
                currentlyPlaying[3].updateBalance(pot / 3);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[1].getPoint() == currentlyPlaying[2].getPoint() && currentlyPlaying[2].getPoint() > currentlyPlaying[3].getPoint()) {
                System.out.printf("%n%n%s and %s have won the pot!", currentlyPlaying[1].getName(), currentlyPlaying[2].getName());
                currentlyPlaying[1].updateBalance(pot / 2);
                currentlyPlaying[2].updateBalance(pot / 2);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[1].getPoint() == currentlyPlaying[3].getPoint() && currentlyPlaying[3].getPoint() > currentlyPlaying[2].getPoint()) {
                System.out.printf("%n%n%s and %s have won the pot!", currentlyPlaying[1].getName(), currentlyPlaying[3].getName());
                currentlyPlaying[1].updateBalance(pot / 2);
                currentlyPlaying[3].updateBalance(pot / 2);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[2].getPoint() == currentlyPlaying[3].getPoint() && currentlyPlaying[3].getPoint() > currentlyPlaying[1].getPoint()) {
                System.out.printf("%n%n%s and %s have won the pot!", currentlyPlaying[2].getName(), currentlyPlaying[3].getName());
                currentlyPlaying[2].updateBalance(pot / 2);
                currentlyPlaying[3].updateBalance(pot / 2);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[1].getPoint() > currentlyPlaying[3].getPoint() && currentlyPlaying[1].getPoint() > currentlyPlaying[2].getPoint()) {
                System.out.printf("%n%n%s has won the pot!", currentlyPlaying[1].getName());
                currentlyPlaying[1].updateBalance(pot);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[2].getPoint() > currentlyPlaying[3].getPoint() && currentlyPlaying[2].getPoint() > currentlyPlaying[1].getPoint()) {
                System.out.printf("%n%n%s has won the pot!", currentlyPlaying[2].getName());
                currentlyPlaying[2].updateBalance(pot);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[3].getPoint() > currentlyPlaying[1].getPoint() && currentlyPlaying[3].getPoint() > currentlyPlaying[2].getPoint()) {
                System.out.printf("%n%n%s has won the pot!", currentlyPlaying[3].getName());
                currentlyPlaying[3].updateBalance(pot);
                updateScoreboard(currentlyPlaying, playerNum);
            }

            for (int i = 0; i < nextPlayerCount; i++) {
                if (players[i].getName().equalsIgnoreCase(currentlyPlaying[1].getName())) {
                    players[i] = currentlyPlaying[1];
                } else if (players[i].getName().equalsIgnoreCase(currentlyPlaying[2].getName())) {
                    players[i] = currentlyPlaying[2];
                } else if (players[i].getName().equalsIgnoreCase(currentlyPlaying[3].getName())) {
                    players[i] = currentlyPlaying[3];
                }
            }
        }

        if (playerNum == 2) {
            if (currentlyPlaying[1].getPoint() == currentlyPlaying[2].getPoint()) {
                System.out.printf("%n%n%s and %s have tied, the pot will be shared evenly!", currentlyPlaying[1].getName(), currentlyPlaying[2].getName());
                currentlyPlaying[1].updateBalance(pot / 2);
                currentlyPlaying[2].updateBalance(pot / 2);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[1].getPoint() > currentlyPlaying[2].getPoint()) {
                System.out.printf("%n%n%s has won the pot!", currentlyPlaying[1].getName());
                currentlyPlaying[1].updateBalance(pot);
                updateScoreboard(currentlyPlaying, playerNum);
            } else if (currentlyPlaying[2].getPoint() > currentlyPlaying[1].getPoint()) {
                System.out.printf("%n%n%s has won the pot!", currentlyPlaying[2].getName());
                currentlyPlaying[2].updateBalance(pot);
                updateScoreboard(currentlyPlaying, playerNum);
            }

            for (int i = 0; i < nextPlayerCount; i++) {
                if (players[i].getName().equalsIgnoreCase(currentlyPlaying[1].getName())) {
                    players[i] = currentlyPlaying[1];
                } else if (players[i].getName().equalsIgnoreCase(currentlyPlaying[2].getName())) {
                    players[i] = currentlyPlaying[2];
                }
            }
        }
        print();
    }

    //METHOD PRINT LEADERBOARD
    public static void print() {
        //Opens the target file
        String filename = "ScoreBoard.txt"; // name of the file we want to find
        File myFile;
        myFile = new File(filename);
        System.out.printf("%nOpening file: %s Path: %s%n", myFile.getName(), myFile.getAbsolutePath());

        //READ AND PRINT DATA
        String line;
        System.out.println("Printing contents: \n");

        try {
            Scanner fileStream = new Scanner(myFile); // creates a new scanner

            //read data from file while there is still data to be read
            while (fileStream.hasNext()) {
                line = fileStream.nextLine();
                System.out.println(line);
            }

        } catch (FileNotFoundException e) {
            System.out.println(e);
        }
    }

    // METHOD UPDATE FILE
    public static void updateScoreboard(Player[] currentlyPlaying, int playerNum) {
        String filename = "ScoreBoard.txt";
        File myFile;
        myFile = new File(filename);
        String name = "name";
        String dash = "dash";
        int balance = 0;

        String printNames[] = new String[4]; // Array of names generated from Player array
        int printScore[] = new int[4]; // Array of balances generated from Player array
        for (int i = 0; i < playerNum; i++) {
            printNames[i] = players[i].getName(); // calls upon getName method to retrieve player Name
            printScore[i] = players[i].getBalance(); // calls upon gerBalance method to retrieve player balance
        }


        try {

            FileWriter fWriter = new FileWriter(myFile, false); // changing false to true saves file instead of over writing it.

            Formatter output = new Formatter(fWriter); //


            for (int h = 0; h < playerNum; h++) {
                name = printNames[h];
                balance = printScore[h];
                output.format("%s - %d%n", name, balance);
            }
            output.close();

        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public static void video()
    { // better version by Wu-tang Clan but didn't want you to play it in front of your child so you can pick and choose for yourself :)

        try {

            URI uri= new URI("https://www.youtube.com/results?search_query=how+to+play+ceelo");
            java.awt.Desktop.getDesktop().browse(uri);
            System.out.println("Web page opened in browser");

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}

